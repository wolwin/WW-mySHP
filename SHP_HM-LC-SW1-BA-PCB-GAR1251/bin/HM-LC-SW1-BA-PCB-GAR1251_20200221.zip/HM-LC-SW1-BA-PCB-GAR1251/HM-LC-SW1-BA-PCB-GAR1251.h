//- -----------------------------------------------------------------------------------------------------------------------
//- HomeMatic - Gardena - Ventil
//- HM-LC-SW1-BA-PCB-GAR1251.h
//- Version: 3.2
//- Date: 2020-02-21
//- -----------------------------------------------------------------------------------------------------------------------
// AskSin++
// 2016-10-31 papa            Creative Commons - http://creativecommons.org/licenses/by-nc-sa/3.0/de/
// HB-UNI-Sensor1
// 2019-02-01 Tom Major       Creative Commons - https://creativecommons.org/licenses/by-nc-sa/4.0/
//
// 2020-02-21 Wolfram Winter  Creative Commons - https://creativecommons.org/licenses/by-nc-sa/4.0/
//                            CCU-Einstellungen (Batterie-Schwelle, Geräte-LED) + BatterieCheck + CC1101 Frequenz
//
// You are free to Share & Adapt under the following terms:
// Give Credit, NonCommercial, ShareAlike
//- -----------------------------------------------------------------------------------------------------------------------

#ifndef _HM-LC-Sw1-Ba-PCB-GAR1251_H_
#define _HM-LC-Sw1-Ba-PCB-GAR1251_H_

//---------------------------------------------------------
// !! NDEBUG should be defined when the development and testing is done
//
// #define NDEBUG

//---------------------------------------------------------
// Device Angaben
// Bei mehreren Geräten des gleichen Typs muss Device ID und Device Serial unterschiedlich sein!
// Device ID und Device Serial werden aus dieser .h Datei geholt, um mehrere Geräte ohne weitere
// Änderungen des Sketches flashen zu können.
#define cDEVICE_ID           {0x12, 0x09, 0x01}
#define cDEVICE_SERIAL       "GAR1251001"
//
// Original:
// Device Model  HM-LC-Sw1-Ba-PCB
// Funk-Schaltaktor 1-fach Platine Batterie
#define cDEVICE_MODEL        { 0x00, 0x6C }
#define cDEVICE_FIRMWARE     0x10
//
// Anzahl der Schalt-Kanäle (1 oder 2)
#define cDEVICE_NUM_CHANNELS 2
//
// Geräte-LED
// #define cDEVICE_LED_MODE  0    // Geräte-LED = aus
// #define cDEVICE_LED_MODE  1    // Geräte-LED = ein
#define cDEVICE_LED_MODE     1
//
// ConfigButton - Modus des Anlern-Buttons
// #define cDEVICE_CB_MODE   0    // Anlern-Modus - kurzer Tastendruck
// #define cDEVICE_CB_MODE   1    // Anlern-Modus - langer Tastendruck
#define cDEVICE_CB_MODE      0

//---------------------------------------------------------
// cRESET_ONSTART - Werte-Reset bei Neustart
// not defined (default) - es werden immer die zuletzt gesetzten Werte benutzt
// defined               - cDEVICE_LED_MODE  wird immer bei Modulstart neu gesetzt
//                       - BAT_VOLT_LOW      wird immer bei Modulstart neu gesetzt
// #define cRESET_ONSTART

//---------------------------------------------------------
// Über diese defines wird die Clock festgelegt
// CLOCK_SYSCLOCK: 8MHz Quarz an XTAL oder 8MHz int. RC-Oszillator, Sleep Strom ca. 4uA
// CLOCK_RTC:      8MHz int. RC-Oszillator, 32.768kHz Quarz an XTAL, Sleep Strom ca. 1uA
#define CLOCK_SYSCLOCK
//#define CLOCK_RTC

//---------------------------------------------------------
// Schaltungsvariante und Pins für Batteriespannungsmessung
// https://github.com/TomMajor/SmartHome/tree/master/HB-UNI-Sensor1#messung-der-Batteriespannung
//------------
// #define BAT_SENSOR_MODE   1                 // Standard: tmBattery, UBatt = Betriebsspannung AVR
// #define BAT_SENSOR_MODE   2                 // Batteriespannungsmessung über Spannungsteiler
// #define BAT_SENSOR_MODE   3                 // Batteriespannungsmessung unter Last
#define BAT_SENSOR_MODE      1

//------------
#define BAT_ACT_PIN          9                 // D9
#define BAT_SENS_PIN         A0                // A0
#define BAT_CHECK_TIME       (6UL * 60 * 60)   // alle 6 Stunden Batteriespannung abfragen

//------------
#if BAT_SENSOR_MODE == 1
// 1) Standard: tmBattery, UBatt = Betriebsspannung AVR
#define BAT_SENSOR tmBattery
#endif
//------------
#if BAT_SENSOR_MODE == 2
// 2) für StepUp/StepDown: tmBatteryResDiv, sense pin A0, activation pin D9, Faktor = Rges/Rlow*1000, z.B. 470k/100k, Faktor 570k/100k*1000 = 5700
// #define BAT_SENSOR tmBatteryResDiv<A0, 9, 5700>
// 1000k/100k, Faktor 1100k/100k*1000 = 11000
// #define BAT_SENSOR tmBatteryResDiv<BAT_SENS_PIN, BAT_ACT_PIN, 11000>
// evtl. wg. Bauteiltoleranzen anpassen
// #define BAT_SENSOR tmBatteryResDiv<BAT_SENS_PIN, BAT_ACT_PIN, 10400>
#define BAT_SENSOR tmBatteryResDiv<BAT_SENS_PIN, BAT_ACT_PIN, 10750>
// #define BAT_SENSOR tmBatteryResDiv<BAT_SENS_PIN, BAT_ACT_PIN, 10980>
// #define BAT_SENSOR tmBatteryResDiv<BAT_SENS_PIN, BAT_ACT_PIN, 11170>
#endif
//------------
#if BAT_SENSOR_MODE == 3
// 3) Echte Batteriespannungsmessung unter Last, siehe README und Thema "Babbling Idiot Protection"
// tmBatteryLoad: sense pin A0, activation pin D9, Faktor = Rges/Rlow*1000, z.B. 10/30 Ohm, Faktor 40/10*1000 = 4000, 200ms Belastung vor Messung
// #define BAT_SENSOR tmBatteryLoad<BAT_SENS_PIN, BAT_ACT_PIN, 4000, 200>
#endif

//---------------------------------------------------------
// Schwellwerte für Batteriespannungsmessung
//
#if BAT_SENSOR_MODE == 1
	    // in der CCU können 'beliebige' Bat-Werte eingegeben werden - sie werden nicht
		// übernommen - der Bat-Wert wird automatisch auf BAT_VOLT_LOW gesetzt - Achtung:
		// in der CCU wird der abgeänderte Bat-Wert nicht angezeigt
#define BAT_VOLT_LOW         31    // 3.1V
#define BAT_VOLT_CRITICAL    30    // 3.0V
#else
	    // in der CCU können Bat-Werte zwischen BAT_VOLT_CRITICAL und BAT_VOLT_LOW_MAX 
		// eingegeben werden - andernfalls wird der Bat-Wert automatisch auf BAT_VOLT_LOW 
		// gesetzt - Achtung: in der CCU wird der evtl. geänderte Bat-Wert nicht angezeigt
#define BAT_VOLT_LOW_MAX     90    // 9.0V
#define BAT_VOLT_LOW         81    // 8.1V
#define BAT_VOLT_CRITICAL    79    // 7.9V
#endif

//---------------------------------------------------------
// Frequenz-Einstellung für CC1101 Sende-Modul
// Standard-Wert = 0x21656A = 868.299866 MHz 
//
// not defined (default) - keine CC1101 eigene Frequenz-Initialisierung
// defined               - CC1101 Frequenz-Initialisierung mit der unten angegebenen Frequenz
// #define USE_CC1101_INIT

#ifdef USE_CC1101_INIT
// Hier den ermittelten Frequenz-Wert aus FreqTest.ino eintragen
// Anmerkung: beim Start von AskSin++ wird das CC1101 Modul mit der Standardfrequenz bzw. 
// mit einem Frequenz-Wert aus dem EEPROM intialisiert.
// Bei gesetztem #define wird das CC1101 Modul auf den folgenden Frequenz-Wert eingestellt:
#define CC1101_FREQ2_VAL     0x21  // 0x21
#define CC1101_FREQ1_VAL     0x65  // 0x65
#define CC1101_FREQ0_VAL     0xA2  // 0x6A
#endif

//---------------------------------------------------------
// Pin und Address Definitionen
//
// set to 0x01 if the RELAY should be switched on LOW level
#define LOW_ACTIVE           0x00
#define ENABLE_PIN           15    // A1
#define RELAY1_ON_PIN        6     // D6
#define RELAY1_OFF_PIN       3     // D3
#define RELAY2_ON_PIN        17    // A3
#define RELAY2_OFF_PIN       16    // A2

//---------------------------------------------------------
// Arduino Pro mini 8 Mhz
// Arduino pin for the config button
#define CONFIG_BUTTON_PIN    8
#define LED_PIN              4

#define CC1101_GDO0_PIN      2
#define CC1101_CS_PIN        10
#define CC1101_MOSI_PIN      11
#define CC1101_MISO_PIN      12
#define CC1101_SCK_PIN       13

#endif
