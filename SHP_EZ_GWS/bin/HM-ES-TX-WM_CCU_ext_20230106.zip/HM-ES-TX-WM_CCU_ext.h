//- -----------------------------------------------------------------------------------------------------------------------
//- HM-ES-TX-WM_CCU_ext.h
//- Version: 1.0
//- Date: 2022-08-02
//- -----------------------------------------------------------------------------------------------------------------------
// AskSin++
// 2016-10-31 papa            Creative Commons - http://creativecommons.org/licenses/by-nc-sa/3.0/de/
// 2018-04-16 jp112sdl        Creative Commons - https://creativecommons.org/licenses/by-nc-sa/4.0/
// 2022-08-02 wolwin          Creative Commons - https://creativecommons.org/licenses/by-nc-sa/4.0/
//                            CCU-Einstellungen (Geräte-LED) + BatterieCheck + CC1101 Frequenz
//
// You are free to Share & Adapt under the following terms:
// Give Credit, NonCommercial, ShareAlike
//- -----------------------------------------------------------------------------------------------------------------------

#ifndef _HM_ES_TX_WM_CCU_ext_H_
#define _HM_ES_TX_WM_CCU_ext_H_

//---------------------------------------------------------
// !! NDEBUG should be defined when the development and testing is done
//
// #define NDEBUG

//---------------------------------------------------------
// set USE_WOR if a battery is used for power
// not defined (default) - Device Model:
// defined               - Device Model:
// #define USE_WOR
// #define USE_WOR

//---------------------------------------------------------
// Device Angaben
//
// Device Model  HM-ES-TX-WM_CCU
// Homematic Zählersensor-Sendeeinheit Strom/Gas HM-ES-TX-WM
// https://github.com/jp112sdl/Beispiel_AskSinPP/tree/master/examples/HM-ES-TX-WM_CCU
#define cDEVICE_ID      { 0x90, 0x12, 0x01 }
#define cDEVICE_SERIAL  "ESTXWMC001"
#define cDEVICE_MODEL   {0x00, 0xDE}    

//---------------------------------------------------------
// Geräte-LED
// #define cDEVICE_LED_MODE  0    // Geräte-LED = aus
// #define cDEVICE_LED_MODE  1    // Geräte-LED = ein
#define cDEVICE_LED_MODE     1
//
#if cDEVICE_LED_MODE == 0
#define DEVICE_LED_MODE  NoLed
#else
#define DEVICE_LED_MODE  StatusLed<LED_PIN>
#endif

//---------------------------------------------------------
// ConfigButton - Modus des Anlern-Buttons
// #define cDEVICE_CB_MODE   0    // Anlern-Modus - kurzer Tastendruck
// #define cDEVICE_CB_MODE   1    // Anlern-Modus - langer Tastendruck
#define cDEVICE_CB_MODE      0

//---------------------------------------------------------
// Batterie-Limit [V*10]
// -- 2 AA(A) Batterien --
// #define cBAT_LOW_LIMIT         22
// #define cBAT_CRT_LIMIT         19
// -- 3 AA(A) Batterien --
#define cBAT_LOW_LIMIT         32
#define cBAT_CRT_LIMIT         30
#define cBAT_CHK_TIME          (1UL * 60 * 60)  // measure battery every 1h

//---------------------------------------------------------
// Korrekturfaktor der Clock-Ungenauigkeit, wenn kein RTC verwendet wird
#define SYSCLOCK_FACTOR        0.88

//---------------------------------------------------------
// Sende-Intervall [sec]
// #define cSEND_INTERVAL         180    // Sekunden
#define cSEND_INTERVAL         180

//---------------------------------------------------------
// Schaltungsvariante und Pins für Batteriespannungsmessung
//------------
// #define BAT_SENSOR_MODE   0                 // keine Batteriespannungsmessung
// #define BAT_SENSOR_MODE   1                 // Standard: UBatt = Betriebsspannung AVR
// #define BAT_SENSOR_MODE   2                 // Batteriespannungsmessung über Spannungsteiler

#ifdef USE_WOR
// mit Batterie-Betrieb
#define BAT_SENSOR_MODE      2
#else
// ohne Batterie-Betrieb
#define BAT_SENSOR_MODE      0
#endif

//
//------------
#if BAT_SENSOR_MODE == 0
// keine Batteriespannungsmessung
#define BAT_SENSOR NoBattery
#endif
//------------
#if BAT_SENSOR_MODE == 1
// 1) Standard: UBatt = Betriebsspannung AVR
#define BAT_SENSOR BatterySensor
#endif
//------------
#if BAT_SENSOR_MODE == 2
// 2) Für StepUp/StepDown: sense pin A0, activation pin D9, Faktor = (Rges/Rlow)*10
#define BAT_EN_PIN           9                 // D9
#define BAT_SENS_PIN         A0                // A0
// R2=470k und R3=100k => Faktor ((470k+100K)/100k)*10 = 57
// #define BAT_SENSOR BatterySensorX<BAT_SENS_PIN, BAT_EN_PIN, 0, 57>
// oder
// R2=1000k und R3=100k => Faktor ((1000k+100K)/100k)*10 = 110
#define BAT_SENSOR BatterySensorX<BAT_SENS_PIN, BAT_EN_PIN, 0, 110>
#endif

//---------------------------------------------------------
// Frequenz-Einstellung für CC1101 Sende-Modul
// Standard-Wert = 0x21656A = 868.299866 MHz 
//
// not defined (default) - keine CC1101 eigene Frequenz-Initialisierung
// defined               - CC1101 Frequenz-Initialisierung mit der unten angegebenen Frequenz
// #define USE_CC1101_INIT

#ifdef USE_CC1101_INIT
// Hier den ermittelten Frequenz-Wert aus FreqTest.ino eintragen
// Anmerkung: beim Start von AskSin++ wird das CC1101 Modul mit der Standardfrequenz bzw. 
// mit einem Frequenz-Wert aus dem EEPROM intialisiert.
// Bei gesetztem #define wird das CC1101 Modul auf den folgenden Frequenz-Wert eingestellt:
#define CC1101_FREQ2_VAL     0x21  // 0x21
#define CC1101_FREQ1_VAL     0x65  // 0x65
#define CC1101_FREQ0_VAL     0xA2  // 0x6A
#endif

//---------------------------------------------------------
// Pin-Anschluesse fuer die Zaehlimpulse
// A0 == PIN 14 on Pro Mini
#define COUNTER1_PIN A1
#define COUNTER2_PIN A2

//---------------------------------------------------------
// Arduino Pro mini 8 Mhz
// Arduino pin for the config button
#define CONFIG_BUTTON_PIN      8
#define LED_PIN                4

#define CC1101_GDO0_PIN        2
#define CC1101_CS_PIN          10
#define CC1101_MOSI_PIN        11
#define CC1101_MISO_PIN        12
#define CC1101_SCK_PIN         13

#endif
