//---------------------------------------------------------
// HB_UNI_Sen_CAP_MOIST_ext.h
//---------------------------------------------------------
// 2016-10-31 papa Creative Commons
// 2019-05-03 jp112sdl Creative Commons
// 2019-05-04 stan23 Creative Commons
// 2020-02-03 Wolfram Winter Creative Commons
// http://creativecommons.org/licenses/by-nc-sa/3.0/de/
// You are free to Share & Adapt under the following terms:
// Give Credit, NonCommercial, ShareAlike
//---------------------------------------------------------

#ifndef _HB_UNI_Sen_CAP_MOIST_ext_H_
#define _HB_UNI_Sen_CAP_MOIST_ext_H_

//---------------------------------------------------------
// !! NDEBUG should be defined when the development and testing is done
//
// #define NDEBUG

//---------------------------------------------------------
// Hardware Konfiguration
//

// Uncomment to use model without temperature sensor DS18B20
// #define NO_DS18B20

// Uncomment to use model without N-MOSFET support
// #define NO_MOSFET

//---------------------------------------------------------
// Device Angaben
//
// Device Model  HB-UNI-Sen-CAP-MOIST
// kapazitiver Bodenfeuchtesensor
// optional mit DS18B20 Temperatursensor
// F3 11  - HB-UNI-Sen-CAP-MOIST 
// F3 12  - HB-UNI-Sen-CAP-MOIST-T 
// https://github.com/jp112sdl/JP-HB-Devices-addon
#ifdef NO_DS18B20
#define DEVICE_MODEL  0x11
#else
#define DEVICE_MODEL  0x12
#endif

#define cDEVICE_ID      { 0xF3, DEVICE_MODEL, 0x05 }
#define cDEVICE_SERIAL  "CAPMOIST05"
#define cDEVICE_MODEL   {0xF3, DEVICE_MODEL}    

//---------------------------------------------------------
// Batterie-Limit [V*10]
// -- 2 AA(A) Batterien --
// #define cBAT_LOW_LIMIT         22
// #define cBAT_CRT_LIMIT         19
// -- 3 AA(A) Batterien --
#define cBAT_LOW_LIMIT         32
#define cBAT_CRT_LIMIT         30

//---------------------------------------------------------
// Korrekturfaktor der Clock-Ungenauigkeit, wenn keine RTC verwendet wird
#define SYSCLOCK_FACTOR        0.885

//---------------------------------------------------------
// Sende-Intervall [sec]
#define cSEND_INTERVAL         10     // Minuten

//---------------------------------------------------------
// cRESET_ONSTART - Werte-Reset bei Neustart
// not defined (default) - es wird immer der zuletzt gesetzten Werte benutzt
// defined               - cSEND_INTERVAL wird immer bei Modulstart neu gesetzt
//                       - cBAT_LOW_LIMIT wird immer bei Modulstart neu gesetzt
// #define cRESET_ONSTART

//---------------------------------------------------------
// Pin-Anschluesse der Feuchtesensoren
// const uint8_t SENSOR_PINS[]    {A1};            // AOut Pin fuer  1 Sensor   (hier: A1)
// const uint8_t SENSOR_PINS[]    {A1, A2);        // AOut Pins fuer 2 Sensoren (hier: A1 und A2)
// const uint8_t SENSOR_PINS[]    {A1, A2, A3};    // AOut Pins fuer 3 Sensoren (hier: A1, A2 und A3)
const uint8_t SENSOR_PINS[]    {A1};

// Bei Verwendung von > 3 Sensoren sollten die Vcc der Sensoren auf 2 Enable Pins verteilt werden (max. Last pro AVR-Pin beachten!)
const uint8_t SENSOR_EN_PINS[] {6};

//---------------------------------------------------------
// Analoge Startwerte des Feuchtesensors
#define cANALOG_HIGH           880   // trocken
#define cANALOG_LOW            460   // nass

//---------------------------------------------------------
// Pin-Anschluss des DS18B20 Sensors
#ifndef NO_DS18B20
#define ONEWIRE_PIN            3
#endif

//---------------------------------------------------------
// Fehler-Temperaturwert DS18B20
#ifndef NO_DS18B20
#define DS18B20_TEMP_ERROR     999   // Temp * 10
#endif

//---------------------------------------------------------
// Pin-Anschluss des N-MOSFET
#ifndef NO_MOSFET
#define SENS_MOSFET_PIN        7 
#define SENS_MOSFET_DELAY      500
#endif

//---------------------------------------------------------
// Arduino Pro mini 8 Mhz
// Arduino pin for the config button
#define CONFIG_BUTTON_PIN      8
#define LED_PIN                4
#define BATT_EN_PIN            9
#define BATT_SENS_PIN          A0

#define CC1101_GDO0_PIN        2
#define CC1101_CS_PIN          10
#define CC1101_MOSI_PIN        11
#define CC1101_MISO_PIN        12
#define CC1101_SCK_PIN         13

#endif
