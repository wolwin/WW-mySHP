//- -----------------------------------------------------------------------------------------------------------------------
//- HB_LC_BL1_Velux_ext.h
//- Version: 1.0
//- Date: 2020-07-22
//- -----------------------------------------------------------------------------------------------------------------------
// AskSin++
// 2016-10-31 papa       Creative Commons - http://creativecommons.org/licenses/by-nc-sa/3.0/de/
// HB-LC-Bl1-Velux
// 2020-05-02 papa       Creative Commons - https://creativecommons.org/licenses/by-nc-sa/4.0/
// 2020-07-22 wolwin     Creative Commons - https://creativecommons.org/licenses/by-nc-sa/4.0/
//                       - some testing, impovement and configuration extentions 
//
// You are free to Share & Adapt under the following terms:
// Give Credit, NonCommercial, ShareAlike
//- -----------------------------------------------------------------------------------------------------------------------

#ifndef _HB_LC_BL1_Velux_ext_H_
#define _HB_LC_BL1_Velux_ext_H_

//---------------------------------------------------------
// !! NDEBUG should be defined when the development and testing is done
//
// #define NDEBUG

//---------------------------------------------------------
// set USE_WOR if a battery is used for power
// not defined (default) - Device Model: HM-LC-Bl1-FM
// defined               - Device Model: HB-LC-Bl1-Velux  (with JP-HB-Devices-addon)
// #define USE_WOR

//---------------------------------------------------------
// set CHANNEL_COUNT to 1 or 2 channels
#define CHANNEL_COUNT  1
// #define CHANNEL_COUNT  2

//---------------------------------------------------------
// Device Angaben
//

// Native RF-Types
// HM-LC-Bl1-FM     0x0005   Funk-Rollladenaktor 1-fach, Unterputzmontage
// HM-LC-Bl1-FM-2   0x00D2   radio-controlled blind actuator 1-channel (flush-mount)
//
// HomeBrew-Types
// HB-LC-BL1-FM-2   0xF207   papa - Jalousieaktor, extra 2 Kanal Blind - da FHEM die dynamische Kanalanzahl nicht kann
// HB-LC-BL1-Velux  0xF20A   papa - Jalousieaktor, extra 2 Kanal Blind - da FHEM die dynamische Kanalanzahl nicht kann

// #define cDEVICE_ID          {0x59,0x32,0xee}
// #define cDEVICE_SERIAL      "papa5932ee"
	
#define cDEVICE_ID      { 0x59, 0x32, 0x01 }
#define cDEVICE_SERIAL  "VELUXKLI01"

#ifndef USE_WOR
// --- ohne Batterie-Betrieb ---
// Device Model  HM-LC-Bl1-FM
#define cDEVICE_MODEL   {0x00, 0x05}

#else
// --- mit Batterie-Betrieb ---
// Device Model  HB-LC-Bl1-Velux
// battery powered radio-controlled blind actuator 1-channel for Velux 
// https://github.com/jp112sdl/JP-HB-Devices-addon
// needs AddOn 'JP HP Devices'
// https://github.com/jp112sdl/JP-HB-Devices-addon/releases
#define cDEVICE_MODEL   {0xF2, 0x0A}

#endif

//---------------------------------------------------------
// Geräte-LED
// #define cDEVICE_LED_MODE  0    // Geräte-LED = aus
// #define cDEVICE_LED_MODE  1    // Geräte-LED = ein
#define cDEVICE_LED_MODE     1
//
#if cDEVICE_LED_MODE == 0
#define DEVICE_LED_MODE  NoLed
#else
#define DEVICE_LED_MODE  StatusLed<LED_PIN>
#endif

//---------------------------------------------------------
// ConfigButton - Modus des Anlern-Buttons
// #define cDEVICE_CB_MODE   0    // Anlern-Modus - kurzer Tastendruck
// #define cDEVICE_CB_MODE   1    // Anlern-Modus - langer Tastendruck
#define cDEVICE_CB_MODE      0

//---------------------------------------------------------
// Batterie-Limit [V*10]
// -- 2 AA(A) Batterien --
#define cBAT_LOW_LIMIT       22
#define cBAT_CRT_LIMIT       19
// -- 3 AA(A) Batterien --
// #define cBAT_LOW_LIMIT       32
// #define cBAT_CRT_LIMIT       30
// -- Intervall Batterie-Test --
#define cBAT_CHK_TIME        (1UL * 60 * 60)   // measure battery every 1h

//---------------------------------------------------------
// Schaltungsvariante und Pins für Batteriespannungsmessung
//------------
// #define BAT_SENSOR_MODE   0                 // keine Batteriespannungsmessung
// #define BAT_SENSOR_MODE   1                 // Standard: UBatt = Betriebsspannung AVR
// #define BAT_SENSOR_MODE   2                 // Batteriespannungsmessung über Spannungsteiler

#ifdef USE_WOR
// mit Batterie-Betrieb
// #define BAT_SENSOR_MODE      1
// #define BAT_SENSOR_MODE      2
#define BAT_SENSOR_MODE      1
#else
// ohne Batterie-Betrieb
#define BAT_SENSOR_MODE      0
#endif

//
//------------
#if BAT_SENSOR_MODE == 0
// keine Batteriespannungsmessung
#define BAT_SENSOR NoBattery
#endif
//------------
#if BAT_SENSOR_MODE == 1
// 1) Standard: UBatt = Betriebsspannung AVR
#define BAT_SENSOR BatterySensor
#endif
//------------
#if BAT_SENSOR_MODE == 2
// 2) Für StepUp/StepDown: sense pin A0, activation pin D9, Faktor = (Rges/Rlow)*10
#define BAT_EN_PIN           9                 // D9
#define BAT_SENS_PIN         A0                // A0
// R2=470k und R3=100k => Faktor ((470k+100K)/100k)*10 = 57
#define BAT_SENSOR BatterySensorX<BAT_SENS_PIN, BAT_EN_PIN, 0, 57>
// oder
// R2=1000k und R3=100k => Faktor ((1000k+100K)/100k)*10 = 110
// #define BAT_SENSOR BatterySensorX<BATT_SENS_PIN, BATT_EN_PIN, 0, 110>
// #define BAT_SENSOR BatterySensorX<BAT_SENS_PIN, BAT_EN_PIN, 0, 110>
#endif

//---------------------------------------------------------
// Frequenz-Einstellung für CC1101 Sende-Modul
// Standard-Wert = 0x21656A = 868.299866 MHz 
//
// not defined (default) - keine CC1101 eigene Frequenz-Initialisierung
// defined               - CC1101 Frequenz-Initialisierung mit der unten angegebenen Frequenz
// #define USE_CC1101_INIT

#ifdef USE_CC1101_INIT
// Hier den ermittelten Frequenz-Wert aus FreqTest.ino eintragen
// Anmerkung: beim Start von AskSin++ wird das CC1101 Modul mit der Standardfrequenz bzw. 
// mit einem Frequenz-Wert aus dem EEPROM intialisiert.
// Bei gesetztem #define wird das CC1101 Modul auf den folgenden Frequenz-Wert eingestellt:
#define CC1101_FREQ2_VAL     0x21  // 0x21
#define CC1101_FREQ1_VAL     0x65  // 0x65
#define CC1101_FREQ0_VAL     0xA2  // 0x6A
#endif

//---------------------------------------------------------
// Pin-Anschluesse des benutzten Boards

#ifdef USE_WOR
  // pins used with battery operation
  // channel 1
  #define UP_PIN             5
  #define STOP_PIN           6
  #define DOWN_PIN           7
#if CHANNEL_COUNT == 2
  // channel 2
  #define UP_PIN2            15
  #define STOP_PIN2          16
  #define DOWN_PIN2          17
#endif
#else
  // pins used without battery operation
  // channel 1
  #define UP_PIN             5   // 19
  #define STOP_PIN           6   // 3
  #define DOWN_PIN           7   // 6
#if CHANNEL_COUNT == 2
  // channel 2
  #define UP_PIN2            15  // 14
  #define STOP_PIN2          16  // 15
  #define DOWN_PIN2          17  // 16
#endif
#endif

//---------------------------------------------------------
// Arduino Pro mini 8 Mhz
// Arduino pin for the config button
#define CONFIG_BUTTON_PIN      8
// Arduino pin for the LED
#define LED_PIN                4

#define CC1101_GDO0_PIN        2
#define CC1101_CS_PIN          10
#define CC1101_MOSI_PIN        11
#define CC1101_MISO_PIN        12
#define CC1101_SCK_PIN         13

#endif
