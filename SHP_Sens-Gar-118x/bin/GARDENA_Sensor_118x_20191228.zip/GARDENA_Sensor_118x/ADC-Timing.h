/*
 * ADC-Timing.h
 *
 * Created: 02.01.2015 11:24:41
 *  Author: Ulli
 *
 * http://bienonline.magix.net/public/avr-libs-adc-timing.html
 * http://bienonline.magix.net/public/avr-lib/adc-timing.rar
 *
 * 30.05.2015: Es wird gepr�ft, ob F_CPU definiert ist.
 */

#if !defined(F_CPU)
  #error F_CPU must be defined!
#endif

#define ADC_CLK (F_CPU / ADC_PRESCALER)
#define ADC_PRESCALER 2U
#define ADC_PRESCALER_MASK 0x0U

#if (ADC_CLK > ADC_CLK_MAX)
  #undef ADC_PRESCALER
  #undef ADC_PRESCALER_MASK
  #define ADC_PRESCALER 4U
  #define ADC_PRESCALER_MASK 0x2U
#endif

#if (ADC_CLK > ADC_CLK_MAX)
  #undef ADC_PRESCALER
  #undef ADC_PRESCALER_MASK
  #define ADC_PRESCALER 8U
  #define ADC_PRESCALER_MASK 0x3U
#endif

#if (ADC_CLK > ADC_CLK_MAX)
  #undef ADC_PRESCALER
  #undef ADC_PRESCALER_MASK
  #define ADC_PRESCALER 16U
  #define ADC_PRESCALER_MASK 0x4U
#endif

#if (ADC_CLK > ADC_CLK_MAX)
  #undef ADC_PRESCALER
  #undef ADC_PRESCALER_MASK
  #define ADC_PRESCALER 32U
  #define ADC_PRESCALER_MASK 0x5U
#endif

#if (ADC_CLK > ADC_CLK_MAX)
  #undef ADC_PRESCALER
  #undef ADC_PRESCALER_MASK
  #define ADC_PRESCALER 64U
  #define ADC_PRESCALER_MASK 0x6U
#endif

#if (ADC_CLK > ADC_CLK_MAX)
  #undef ADC_PRESCALER
  #undef ADC_PRESCALER_MASK
  #define ADC_PRESCALER 128U
  #define ADC_PRESCALER_MASK 0x7U
#endif

// Grenzen f�r ADC_CLK �berpr�fen.
#if (ADC_CLK < ADC_CLK_MIN)
  #error No ADC prescaler exists for ADC_CLK_MIN <= clkADC.
#endif
#if (ADC_CLK > ADC_CLK_MAX)
  #error No ADC prescaler exists for clkADC <= ADC_CLK_MAX.
#endif