// =======================================================================
// Sens_GARDENA_118x.h
// =======================================================================
// Function:
// Sensor class for GARDENA 118x circuit board
// =======================================================================
//
// (c) by Dipl.-Ing. Wolfram Winter - wolfram.winter@web.de
// 
// This work is licensed under a
// Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.
// 
// You should have received a copy of the license along with this work. If
// not, see <http://creativecommons.org/licenses/by-nc-sa/4.0/>.
//
// =======================================================================
// Documentation:
// https://github.com/wolwin/
//
// Based on:
// - AskSin++ 2016-10-31 papa
//   https://github.com/pa-pa/AskSinPP
//   Creative Commons BY-NC-SA 3.0 DE
//   http://creativecommons.org/licenses/by-nc-sa/3.0/de/
// - 2018-10-26 HB-SCI-3-FM Tom Major
//   https://github.com/TomMajor/SmartHome/tree/master/HB-UNI-Sensor1
//   Creative Commons BY-NC-SA 4.0
//   http://creativecommons.org/licenses/by-nc-sa/4.0/
// - You are free to Share & Adapt under the following terms:
//   Give Credit, NonCommercial, ShareAlike
// =======================================================================
// History:
// Created: 09.08.2019 - Wolfram Winter
//   State: 27.12.2019 - Wolfram Winter
//           - Verifyed
//
// =======================================================================
// Remarks: -
//
// =======================================================================

#ifndef _SENS_GARDENA_118x_H_
#define _SENS_GARDENA_118x_H_

#include <Sensors.h>

namespace as {

class Sens_GARDENA_118x : public Sensor {

     uint8_t  _garReadBit;
     bool     _garReadFlag;

public:

    bool init()
    {
        _garReadBit  = 0;
        _garReadFlag = false;
        pinMode(SENSOR_GARDENA_1_Status, INPUT);
        pinMode(SENSOR_GARDENA_1_Error,  INPUT);
        pinMode(SENSOR_GARDENA_2_Status, INPUT);
        pinMode(SENSOR_GARDENA_2_Error,  INPUT);
        delay(100);
		return false;
    }

    uint8_t measure()
    {
        uint8_t  digPortState;

        // -------------------------------
        // Gardena Status/Error - Umwandlung in 4-Bit Wert (fuer custom payload Uebertragung)
		//
        //          INP Status Error
        // -------------------------------
        // Bit ----------- 1 --- 2 ----
        // xx00 (0)  1     0     0    kein Fehler (Gardena-Kabel ist angeschlossen)  - Sensor-Status 1 OFF
        // xx01 (1)  1     1     0    kein Fehler (Gardena-Kabel ist angeschlossen)  - Sensor-Status 1 ON
        // xx10 (2)  1     0     1    Fehler (Gardena-Kabel ist nicht angeschlossen) - Sensor-Status 1 OFF
        // xx11 (3)  1     1     1    kommt so nicht vor - bei Fehler (Gardena-Kabel ist nicht angeschlossen) wird Sensor-Status auf OFF gesetzt
        // Bit ----------- 3 --- 4 ----
        // 00xx (0)  2     0     0    kein Fehler (Gardena-Kabel ist angeschlossen)  - Sensor-Status 2 OFF
        // 01xx (4)  2     1     0    kein Fehler (Gardena-Kabel ist angeschlossen)  - Sensor-Status 2 ON
        // 10xx (8)  2     0     1    Fehler (Gardena-Kabel ist nicht angeschlossen) - Sensor-Status 2 OFF
        // 11xx (12) 2     1     1    kommt so nicht vor - bei Fehler (Gardena-Kabel ist nicht angeschlossen) wird Sensor-Status auf OFF gesetzt
        // -------------------------------

        _garReadBit = 0;

        digPortState = digitalRead(SENSOR_GARDENA_1_Status);
        if (digPortState) { _garReadBit += 1; }
        // DPRINT("GARDENA_1_Status: ");
        // DDECLN(digPortState);
        
        digPortState = digitalRead(SENSOR_GARDENA_1_Error);
        if (digPortState) { _garReadBit += 2; }
        // DPRINT("GARDENA_1_Error: ");
        // DDECLN(digPortState);

        digPortState = digitalRead(SENSOR_GARDENA_2_Status);
        if (digPortState) { _garReadBit += 4; }
        // DPRINT("GARDENA_2_Status: ");
        // DDECLN(digPortState);

        digPortState = digitalRead(SENSOR_GARDENA_2_Error);
        if (digPortState) { _garReadBit += 8; }
        // DPRINT("GARDENA_2_Error: ");
        // DDECLN(digPortState);

        _garReadFlag = true;
		
        // DPRINT("GARDENA_4-Bit: ");
        // DDECLN(_garReadBit);

        return (_garReadBit);
    }
	
    bool notifyGarRead() { return _garReadFlag; }
    void resetGarRead()  { _garReadFlag = false; }
    void setGarRead()    { _garReadFlag = true; }

};

}

#endif
