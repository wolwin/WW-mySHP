// =======================================================================
// HB-SCI-4-O-Gar118x.h
// =======================================================================
//
// (c) by Dipl.-Ing. Wolfram Winter - wolfram.winter@web.de
// 
// This work is licensed under a
// Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.
// 
// You should have received a copy of the license along with this work. If
// not, see <http://creativecommons.org/licenses/by-nc-sa/4.0/>.
//
// =======================================================================
// Documentation:
// https://github.com/wolwin/
//
// Based on:
// - AskSin++ 2016-10-31 papa
//   https://github.com/pa-pa/AskSinPP
//   Creative Commons BY-NC-SA 3.0 DE
//   http://creativecommons.org/licenses/by-nc-sa/3.0/de/
// - 2018-10-26 HB-SCI-3-FM Tom Major
//   https://github.com/TomMajor/SmartHome/tree/master/HB-SCI-3-FM
//   https://github.com/TomMajor/SmartHome/tree/master/HB-UNI-Sensor1
//   Creative Commons BY-NC-SA 4.0
//   http://creativecommons.org/licenses/by-nc-sa/4.0/
// - You are free to Share & Adapt under the following terms:
//   Give Credit, NonCommercial, ShareAlike
// =======================================================================
// History:
// Created: 01.12.2019 - Wolfram Winter
//   State: 30.12.2019 - Wolfram Winter
//           - Verifyed
//          23.03.2020 - Wolfram Winter
//           - force CCU toogle update every INPUT_MEASURE_TIMELOOP 
// =======================================================================

#ifndef _HB-SCI-4-O-Gar118x_H_
#define _HB-SCI-4-O-Gar118x_H_

//---------------------------------------------------------
// !! NDEBUG should be defined when the development and testing is done
//
// #define NDEBUG

//---------------------------------------------------------
// Device Angaben
// Bei mehreren Geräten des gleichen Typs muss Device ID und Device Serial unterschiedlich sein!
// Device ID und Device Serial werden aus dieser .h Datei geholt, um mehrere Geräte ohne weitere
// Änderungen des Sketches flashen zu können.
#define cDEVICE_ID           { 0x19, 0x12, 0x01 }
#define cDEVICE_SERIAL       "GAR118X001"
//
// Original:
// Device Model  HM-SCI-3-FM
// Funk-Schließerkontaktschnittstelle 3-fach, Unterputzmontage
#define cDEVICE_MODEL        { 0x00, 0x5F }
#define cDEVICE_FIRMWARE     0x10
//
// ConfigButton - Modus des Anlern-Buttons
// #define cDEVICE_CB_MODE   0    // Anlern-Modus - kurzer Tastendruck
// #define cDEVICE_CB_MODE   1    // Anlern-Modus - langer Tastendruck
#define cDEVICE_CB_MODE      0

//---------------------------------------------------------
// Über diese defines wird die Clock festgelegt
// CLOCK_SYSCLOCK: 8MHz Quarz an XTAL oder 8MHz int. RC-Oszillator, Sleep Strom ca. 4uA
// CLOCK_RTC:      8MHz int. RC-Oszillator, 32.768kHz Quarz an XTAL, Sleep Strom ca. 1uA
#define CLOCK_SYSCLOCK
//#define CLOCK_RTC

//---------------------------------------------------------
// Definitionen Allgemein
#define CONFIG_BUTTON_PIN    8
#define LED_PIN              4
// Number of available peers per channel
#define PEERS_PER_CHANNEL    6

//---------------------------------------------------------
// Schaltungsvariante und Pins für Batteriespannungsmessung
// https://github.com/TomMajor/SmartHome/tree/master/HB-UNI-Sensor1#messung-der-Batteriespannung
//------------
// 1) Standard: tmBattery, UBatt = Betriebsspannung AVR
// #define BAT_SENSOR tmBattery
//------------
// 2) für StepUp/StepDown: tmBatteryResDiv, sense pin A0, activation pin D9, Faktor = Rges/Rlow*1000, z.B. 470k/100k, Faktor 570k/100k*1000 = 5700
// #define BAT_SENSOR tmBatteryResDiv<A0, 9, 5700>

//1000k/100k, Faktor 1100k/100k*1000 = 11000
// #define BAT_SENSOR tmBatteryResDiv<A0, 9, 11000>

//#define BAT_SENSOR tmBatteryResDiv<A0, 9, 10400>
#define BAT_SENSOR tmBatteryResDiv<A0, 9, 10930>
//#define BAT_SENSOR tmBatteryResDiv<A0, 9, 10980>
//#define BAT_SENSOR tmBatteryResDiv<A0, 9, 11170>

//------------
// 3) Echte Batteriespannungsmessung unter Last, siehe README und Thema "Babbling Idiot Protection"
// tmBatteryLoad: sense pin A0, activation pin D9, Faktor = Rges/Rlow*1000, z.B. 10/30 Ohm, Faktor 40/10*1000 = 4000, 200ms Belastung vor Messung
//#define BAT_SENSOR tmBatteryLoad<A0, 9, 4000, 200>

//---------------------------------------------------------
// Schwellwerte für Batteriespannungsmessung
// #define BAT_VOLT_LOW        22                // 2.2V
// #define BAT_VOLT_CRITICAL   19                // 1.9V
#define BAT_VOLT_LOW        32                // 3.2V
#define BAT_VOLT_CRITICAL   29                // 2.9V
#define BAT_VOLT_TIME       (12UL * 60 * 60)  // measure battery every 12h

//---------------------------------------------------------
// Abfrage Definitionen
// mind. 1-mal pro Stunde den Schalter-Status tooglen und an CCU versenden
// #define INPUT_MEASURE_TIMELOOP   (1UL * 60 * 60)
// für Debug-Zwecke 1-mal pro Minute
// #define INPUT_MEASURE_TIMELOOP   (1UL * 60) 

// alle 12 Minuten - den Schalter-Status tooglen und an CCU versenden
#define INPUT_MEASURE_TIMELOOP   (1UL * 12 * 60)

//---------------------------------------------------------
// Pin und Address Definitionen Sensoren
#define DIGINP_PIN               A1    // Toogle Change-Flag from ATtiny 
#define INPUT1_PIN               A2    // Input Status 1 from ATtiny
#define INPUT2_PIN               PD5   // Input Error  1 from ATtiny
#define INPUT3_PIN               A3    // Input Status 2 from ATtiny
#define INPUT4_PIN               PD6   // Input Error  2 from ATtiny

// Definitionen für Sens_GARDENA_118x.h
#define SENSOR_GARDENA_1_Status  INPUT1_PIN
#define SENSOR_GARDENA_1_Error   INPUT2_PIN
#define SENSOR_GARDENA_2_Status  INPUT3_PIN
#define SENSOR_GARDENA_2_Error   INPUT4_PIN

//---------------------------------------------------------
// GARDENA Schaltungs- und System-Varianten
//
// Variante 1 - mit Fehler-Kanal
// Platine 
// Jumper  : J1 = OFF  J2 = OFF
// Inp-Gar1: Gardena 1188-20 (Feuchte)  oder  Gardena 1189-20 (Regen)
// Inp-Gar2: -
// WebUI   : Darstellung 2 Schalter (Status1 / Error1) 
// #define CHANNEL_COUNT   2
// #define CHANNEL_PINS    {INPUT1_PIN, INPUT2_PIN}
// #define CHANNEL_DEBUG   0x0011

// Variante 1 - ohne Fehler-Kanal
// Platine 
// Jumper  : J1 = OFF  J2 = OFF
// Inp-Gar1: Gardena 1188-20 (Feuchte)  oder  Gardena 1189-20 (Regen)
// Inp-Gar2: -
// WebUI   : Darstellung 1 Schalter (Status1) 
// #define CHANNEL_COUNT   1
// #define CHANNEL_PINS    {INPUT1_PIN}
// #define CHANNEL_DEBUG   0x0001

// Variante 2 - mit Fehler-Kanal (default)
// Platine 
// Jumper  : J1 = OFF  J2 = OFF
// Inp-Gar1: Gardena 1188-20 (Feuchte)
// Inp-Gar2: Gardena 1189-20 (Regen)
//   oder
// Inp-Gar1: Bewässerung-Flag - Y-Kabel mit Gardena 1188-20 (Feuchte) und Gardena 1189-20 (Regen)
// Inp-Gar2: Bewässerung-Flag - Y-Kabel mit Gardena 1188-20 (Feuchte) und Gardena 1189-20 (Regen) 
// WebUI   : Darstellung 4 Schalter (Status1 / Error1 / Status2 / Error2)
#define CHANNEL_COUNT   4 
#define CHANNEL_PINS    {INPUT1_PIN, INPUT2_PIN, INPUT3_PIN, INPUT4_PIN}
#define CHANNEL_DEBUG   0x1111

// Variante 2 - ohne Fehler-Kanal
// Platine 
// Jumper  : J1 = OFF  J2 = OFF
// Inp-Gar1: Gardena 1188-20 (Feuchte)
// Inp-Gar2: Gardena 1189-20 (Regen)
//   oder
// Inp-Gar1: Bewässerung-Flag - Y-Kabel mit Gardena 1188-20 (Feuchte) und Gardena 1189-20 (Regen)
// Inp-Gar2: Bewässerung-Flag - Y-Kabel mit Gardena 1188-20 (Feuchte) und Gardena 1189-20 (Regen) 
// WebUI   : Darstellung 2 Schalter (Status1 / Status2) 
// #define CHANNEL_COUNT   2
// #define CHANNEL_PINS    {INPUT1_PIN, INPUT3_PIN}
// #define CHANNEL_DEBUG   0x0101
 
// Variante 3 - mit Fehler-Kanal
// Platine 
// Jumper  : J1 = OFF  J2 = ON
// Inp-Gar1: Gardena 1188-20 (Feuchte)  oder  Gardena 1189-20 (Regen)  oder  Y-Kabel mit Gardena 1188-20 (Feuchte) und Gardena 1189-20 (Regen)
// Inp-Gar2: 1 potentialfreier Schalter
// WebUI   : Darstellung 3 Schalter (Status1 / Error1 / Status2)
// #define CHANNEL_COUNT   3
// #define CHANNEL_PINS    {INPUT1_PIN, INPUT2_PIN, INPUT3_PIN}
// #define CHANNEL_DEBUG   0x0111

// Variante 3 - ohne Fehler-Kanal
// Platine 
// Jumper  : J1 = OFF  J2 = ON
// Inp-Gar1: Gardena 1188-20 (Feuchte)  oder  Gardena 1189-20 (Regen)  oder  Y-Kabel mit Gardena 1188-20 (Feuchte) und Gardena 1189-20 (Regen)
// Inp-Gar2: 1 potentialfreier Schalter
// WebUI   : Darstellung 2 Schalter (Status1 / Status2) 
// #define CHANNEL_COUNT   2
// #define CHANNEL_PINS    {INPUT1_PIN, INPUT3_PIN}
// #define CHANNEL_DEBUG   0x0101
 
// Variante 4
// Platine 
// Jumper  : J1 = ON  J2 = ON
// Inp-Gar1: 1 potentialfreier Schalter
// Inp-Gar2: -
// WebUI   : Darstellung 1 Schalter (Status1) 
// #define CHANNEL_COUNT   1
// #define CHANNEL_PINS    {INPUT1_PIN}
// #define CHANNEL_DEBUG   0x0001

// Variante 4
// Platine 
// Jumper  : J1 = ON  J2 = ON
// Inp-Gar1: 1 potentialfreier Schalter
// Inp-Gar2: 1 potentialfreier Schalter
// WebUI   : Darstellung 2 Schalter (Status1 / Status2) 
// #define CHANNEL_COUNT   2
// #define CHANNEL_PINS    {INPUT1_PIN, INPUT3_PIN}
// #define CHANNEL_DEBUG   0x0101

#endif
