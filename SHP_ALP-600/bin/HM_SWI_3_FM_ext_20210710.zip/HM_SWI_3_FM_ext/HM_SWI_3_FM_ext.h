//- -----------------------------------------------------------------------------------------------------------------------
//- HM_SWI_3_FM_ext.h
//- Version: 1.0
//- Date: 2021-07-10
//- -----------------------------------------------------------------------------------------------------------------------
// AskSin++
// 2016-10-31 papa       Creative Commons - http://creativecommons.org/licenses/by-nc-sa/3.0/de/
// 2020-06-19 jp112sdl   Creative Commons - http://creativecommons.org/licenses/by-nc-sa/3.0/de/
// 2021-07-10 wolwin     Creative Commons - https://creativecommons.org/licenses/by-nc-sa/4.0/
//                       - some testing, impovement and configuration extentions 
//
// You are free to Share & Adapt under the following terms:
// Give Credit, NonCommercial, ShareAlike
//- -----------------------------------------------------------------------------------------------------------------------

#ifndef _HM_SWI_3_FM_ext_H_
#define _HM_SWI_3_FM_ext_H_

//---------------------------------------------------------
// !! NDEBUG should be defined when the development and testing is done
//
// #define NDEBUG

//---------------------------------------------------------
// set USE_WOR if a battery is used for power
// not defined (default) - Device Model: HM-SWI-3-FM ohne Batteriebetrieb
// !!! noch nicht getestet !!!
// defined               - Device Model: HM-SWI-3-FM mit  Batteriebetrieb
// #define USE_WOR


//---------------------------------------------------------
// set CHANNEL_COUNT to 1 to 7 channels
//
#define CHANNEL_COUNT  3
// #define CHANNEL_COUNT  1
// #define CHANNEL_COUNT  7


//---------------------------------------------------------
// Device Angaben
//
// Native RF-Type
// HM-SWI-3-FM     0x0046   Funk-Schalterschnittstelle 3-fach, Unterputzmontage
//
#define cDEVICE_ID      { 0x00, 0x46, 0x01 }
#define cDEVICE_SERIAL  "HMSWI30001"
#define cDEVICE_MODEL   {0x00, 0x46}


//---------------------------------------------------------
// Geräte-LED
// #define cDEVICE_LED_MODE  0    // Geräte-LED = aus
// #define cDEVICE_LED_MODE  1    // Geräte-LED = ein
//
#define cDEVICE_LED_MODE     1
//
#if cDEVICE_LED_MODE == 0
#define DEVICE_LED_MODE  NoLed
#else
#define DEVICE_LED_MODE  StatusLed<LED_PIN>
// #define DEVICE_LED_MODE  DualStatusLed<LED2_PIN, LED1_PIN>
#endif


//---------------------------------------------------------
// ConfigButton - Modus des Anlern-Buttons
// #define cDEVICE_CB_MODE   0    // Anlern-Modus - kurzer Tastendruck
// #define cDEVICE_CB_MODE   1    // Anlern-Modus - langer Tastendruck
//
#define cDEVICE_CB_MODE      0


//---------------------------------------------------------
// Batterie-Limit [V*10]
#ifdef USE_WOR
// -- 2 AA(A) Batterien --
#define cBAT_LOW_LIMIT       22
#define cBAT_CRT_LIMIT       19
// #define cBAT_LOW_LIMIT_MAXVALUE   30
// -- 3 AA(A) Batterien --
// #define cBAT_LOW_LIMIT       32
// #define cBAT_CRT_LIMIT       30
// #define cBAT_LOW_LIMIT_MAXVALUE   40
// --  9V Block Batterie --
// #define cBAT_LOW_LIMIT            81
// #define cBAT_CRT_LIMIT            79
// #define cBAT_LOW_LIMIT_MAXVALUE   90
// -- Intervall Batterie-Test --
#define cBAT_CHK_TIME        (1UL * 60 * 60)   // measure battery every 1h
#endif

//---------------------------------------------------------
// Schaltungsvariante und Pins für Batteriespannungsmessung
//------------
// #define BAT_SENSOR_MODE   0                 // keine Batteriespannungsmessung
// #define BAT_SENSOR_MODE   1                 // Standard: UBatt = Betriebsspannung AVR
// #define BAT_SENSOR_MODE   2                 // Batteriespannungsmessung über Spannungsteiler

#ifdef USE_WOR
// mit Batterie-Betrieb
// #define BAT_SENSOR_MODE      1
// #define BAT_SENSOR_MODE      2
#define BAT_SENSOR_MODE      1
#else
// ohne Batterie-Betrieb
#define BAT_SENSOR_MODE      0
#endif

//
//------------
#if BAT_SENSOR_MODE == 0
// keine Batteriespannungsmessung
#define BAT_SENSOR NoBattery
#endif
//------------
#if BAT_SENSOR_MODE == 1
// 1) Standard: UBatt = Betriebsspannung AVR
#define BAT_SENSOR BatterySensor
#endif
//------------
#if BAT_SENSOR_MODE == 2
// 2) Für StepUp/StepDown: sense pin A0, activation pin D9, Faktor = (Rges/Rlow)*10
#define BAT_EN_PIN           9                 // D9
#define BAT_SENS_PIN         A0                // A0
// R2=470k und R3=100k => Faktor ((470k+100K)/100k)*10 = 57
#define BAT_SENSOR BatterySensor<BAT_SENS_PIN, BAT_EN_PIN, 0, 57>
// oder
// R2=1000k und R3=100k => Faktor ((1000k+100K)/100k)*10 = 110
// #define BAT_SENSOR BatterySensor<BATT_SENS_PIN, BATT_EN_PIN, 0, 110>
// #define BAT_SENSOR BatterySensor<BAT_SENS_PIN, BAT_EN_PIN, 0, 110>
#endif


//---------------------------------------------------------
// Frequenz-Einstellung für CC1101 Sende-Modul
// Standard-Wert = 0x21656A = 868.299866 MHz 
//
// not defined (default) - keine CC1101 eigene Frequenz-Initialisierung
// defined               - CC1101 Frequenz-Initialisierung mit der unten angegebenen Frequenz
// #define USE_CC1101_INIT

#ifdef USE_CC1101_INIT
// Hier den ermittelten Frequenz-Wert aus FreqTest.ino eintragen
// Anmerkung: beim Start von AskSin++ wird das CC1101 Modul mit der Standardfrequenz bzw. 
// mit einem Frequenz-Wert aus dem EEPROM intialisiert.
// Bei gesetztem #define wird das CC1101 Modul auf den folgenden Frequenz-Wert eingestellt:
#define CC1101_FREQ2_VAL     0x21  // 0x21
#define CC1101_FREQ1_VAL     0x65  // 0x65
#define CC1101_FREQ0_VAL     0xA2  // 0x6A
#endif


//---------------------------------------------------------
// Benutzte Pin-Anschluesse des Boards
//
#define IN1_PIN  A1
#define IN2_PIN  A2
#define IN3_PIN  A3
// #define IN4_PIN  9
// #define IN5_PIN  9
// #define IN6_PIN  9
// #define IN7_PIN  9


//---------------------------------------------------------
// Arduino Pro mini 8 Mhz
// Arduino pin for the config button
#define CONFIG_BUTTON_PIN      8
// Arduino pin for the LED
#define LED_PIN                4
// for DualStatusLed
// #define LED1_PIN               4
// #define LED2_PIN               5

#define CC1101_GDO0_PIN        2
#define CC1101_CS_PIN          10
#define CC1101_MOSI_PIN        11
#define CC1101_MISO_PIN        12
#define CC1101_SCK_PIN         13

#endif
