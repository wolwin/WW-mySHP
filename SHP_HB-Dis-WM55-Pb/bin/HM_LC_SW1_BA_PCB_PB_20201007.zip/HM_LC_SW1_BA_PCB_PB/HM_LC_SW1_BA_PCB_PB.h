//- -----------------------------------------------------------------------------------------------------------------------
//- HomeMatic
//- HM_LC_SW1_BA_PCB_PB.h
//- Version: 1.0
//- Date: 2020-08-03
//- -----------------------------------------------------------------------------------------------------------------------
// AskSin++
// 2016-10-31 papa    Creative Commons - http://creativecommons.org/licenses/by-nc-sa/3.0/de/
// 2020-08-03 wolwin  Creative Commons - https://creativecommons.org/licenses/by-nc-sa/4.0/
//                    - Konfiguration für Platine HB-Dis-WM55-Pb (Simulation 2-Kanal Taster)
//
// You are free to Share & Adapt under the following terms:
// Give Credit, NonCommercial, ShareAlike
//- -----------------------------------------------------------------------------------------------------------------------

#ifndef _HM_LC_SW1_BA_PCB_PB_H_
#define _HM_LC_SW1_BA_PCB_PB_H_

//---------------------------------------------------------
// !! NDEBUG should be defined when the development and testing is done
//
// #define NDEBUG

//---------------------------------------------------------
// Device Angaben
// Bei mehreren Geräten des gleichen Typs muss Device ID und Device Serial unterschiedlich sein!
// Device ID und Device Serial werden aus dieser .h Datei geholt, um mehrere Geräte ohne weitere
// Änderungen des Sketches flashen zu können.
#define cDEVICE_ID           {0x20, 0x08, 0x01}
#define cDEVICE_SERIAL       "WM55TAST01"
//
// Original:
// Device Model  HM-LC-Sw1-Ba-PCB
// Funk-Schaltaktor 1-fach Platine Batterie
#define cDEVICE_MODEL        { 0x00, 0x6C }
#define cDEVICE_FIRMWARE     0x10
//
// Anzahl der Schalt-Kanäle (1 ... 4)
#define cDEVICE_NUM_CHANNELS 4
//
// Geräte-LED
// #define cDEVICE_LED_MODE  0    // Geräte-LED = aus
// #define cDEVICE_LED_MODE  1    // Geräte-LED = ein
#define cDEVICE_LED_MODE     1
//
// ConfigButton - Modus des Anlern-Buttons
// #define cDEVICE_CB_MODE   0    // Anlern-Modus - kurzer Tastendruck
// #define cDEVICE_CB_MODE   1    // Anlern-Modus - langer Tastendruck
#define cDEVICE_CB_MODE      0

//---------------------------------------------------------
// cRESET_ONSTART - Werte-Reset bei Neustart
// not defined (default) - es werden immer die zuletzt gesetzten Werte benutzt
// defined               - cDEVICE_LED_MODE  wird immer bei Modulstart neu gesetzt
//                       - BAT_VOLT_LOW      wird immer bei Modulstart neu gesetzt
// #define cRESET_ONSTART

//---------------------------------------------------------
// Batterie-Limit [V*10]
// -- 2 AA(A) Batterien --
// #define cBAT_LOW_LIMIT            20
// #define cBAT_CRT_LIMIT            19
// #define cBAT_LOW_LIMIT_MAXVALUE   30
// -- 3 AA(A) Batterien --
#define cBAT_LOW_LIMIT            32
#define cBAT_CRT_LIMIT            30
#define cBAT_LOW_LIMIT_MAXVALUE   40
// --  9V Block Batterie --
// #define cBAT_LOW_LIMIT            81
// #define cBAT_CRT_LIMIT            79
// #define cBAT_LOW_LIMIT_MAXVALUE   90
// -- Intervall Batterie-Test --
#define cBAT_CHK_TIME   (1UL * 60 * 60)   // measure battery every 1h

//---------------------------------------------------------
// Schaltungsvariante und Pins für Batteriespannungsmessung
//------------
// #define BAT_SENSOR_MODE   0     // keine Batteriespannungsmessung
// #define BAT_SENSOR_MODE   1     // Standard: UBatt = Betriebsspannung AVR
// #define BAT_SENSOR_MODE   2     // Batteriespannungsmessung über Spannungsteiler
#define BAT_SENSOR_MODE      2

//
//------------
#if BAT_SENSOR_MODE == 0
// keine Batteriespannungsmessung
#define BAT_SENSOR NoBattery
#endif
//------------
#if BAT_SENSOR_MODE == 1
// 1) Standard: UBatt = Betriebsspannung AVR
#define BAT_SENSOR BatterySensor
#endif
//------------
#if BAT_SENSOR_MODE == 2
// 2) Für StepUp/StepDown: sense pin A0, activation pin D9, Faktor = (Rges/Rlow)*10
#define BAT_EN_PIN           9     // D9
#define BAT_SENS_PIN         14    // A0
// R2=470k und R3=100k => Faktor ((470k+100K)/100k)*10 = 57
#define BAT_SENSOR BatterySensorX<BAT_SENS_PIN, BAT_EN_PIN, 0, 57>
// oder
// R2=1000k und R3=100k => Faktor ((1000k+100K)/100k)*10 = 110
// #define BAT_SENSOR BatterySensorX<BATT_SENS_PIN, BATT_EN_PIN, 0, 110>
// #define BAT_SENSOR BatterySensorX<BAT_SENS_PIN, BAT_EN_PIN, 0, 110>
#endif

//---------------------------------------------------------
// Schwellwerte für Batteriespannungsmessung
//
#if BAT_SENSOR_MODE == 1
	    // in der CCU können 'beliebige' Bat-Werte eingegeben werden - sie werden nicht
		// übernommen - der Bat-Wert wird automatisch auf BAT_VOLT_LOW gesetzt - Achtung:
		// in der CCU wird der abgeänderte Bat-Wert nicht angezeigt
#define BAT_VOLT_LOW         cBAT_LOW_LIMIT
#define BAT_VOLT_CRITICAL    cBAT_CRT_LIMIT
#else
	    // in der CCU können Bat-Werte zwischen BAT_VOLT_CRITICAL und BAT_VOLT_LOW_MAX 
		// eingegeben werden - andernfalls wird der Bat-Wert automatisch auf BAT_VOLT_LOW 
		// gesetzt - Achtung: in der CCU wird der evtl. geänderte Bat-Wert nicht angezeigt
#define BAT_VOLT_LOW_MAX     cBAT_LOW_LIMIT_MAXVALUE
#define BAT_VOLT_LOW         cBAT_LOW_LIMIT
#define BAT_VOLT_CRITICAL    cBAT_CRT_LIMIT
#endif

//---------------------------------------------------------
// Frequenz-Einstellung für CC1101 Sende-Modul
// Standard-Wert = 0x21656A = 868.299866 MHz 
//
// not defined (default) - keine CC1101 eigene Frequenz-Initialisierung
// defined               - CC1101 Frequenz-Initialisierung mit der unten angegebenen Frequenz
// #define USE_CC1101_INIT

#ifdef USE_CC1101_INIT
// Hier den ermittelten Frequenz-Wert aus FreqTest.ino eintragen
// Anmerkung: beim Start von AskSin++ wird das CC1101 Modul mit der Standardfrequenz bzw. 
// mit einem Frequenz-Wert aus dem EEPROM intialisiert.
// Bei gesetztem #define wird das CC1101 Modul auf den folgenden Frequenz-Wert eingestellt:
#define CC1101_FREQ2_VAL     0x21  // 0x21
#define CC1101_FREQ1_VAL     0x65  // 0x65
#define CC1101_FREQ0_VAL     0xA2  // 0x6A
#endif

//---------------------------------------------------------
// Pin und Address Definitionen
//
#define RELAY_PIN_1          15    // A1
#define RELAY_PIN_2          15    // A1
#define RELAY_PIN_3          16    // A2
#define RELAY_PIN_4          16    // A2

// Länge des Tastendrucks (kurz oder lang) => Schaltzyklus EIN - Pause - AUS
#define RELAY_PIN_1_TIME     500
#define RELAY_PIN_2_TIME     1500
#define RELAY_PIN_3_TIME     500
#define RELAY_PIN_4_TIME     1500

//---------------------------------------------------------
// Arduino Pro mini 8 Mhz
// Arduino pin for the config button
#define CONFIG_BUTTON_PIN    8
#define LED_PIN              4

#define CC1101_GDO0_PIN      2
#define CC1101_CS_PIN        10
#define CC1101_MOSI_PIN      11
#define CC1101_MISO_PIN      12
#define CC1101_SCK_PIN       13

#endif
