//---------------------------------------------------------
// HB-LxR-THT_ext
//---------------------------------------------------------
//
// 2026-08-05 - wolwin Creative Commons
//
// http://creativecommons.org/licenses/by-nc-sa/3.0/de/
// You are free to Share & Adapt under the following terms:
// Give Credit, NonCommercial, ShareAlike
//---------------------------------------------------------

#ifndef _HB-LxR-THT_ext_H_
#define _HB-LxR-THT_ext_H_

//---------------------------------------------------------
// !! NDEBUG should be defined when the development and testing is done
//
// #define NDEBUG

//---------------------------------------------------------
// Hardware Konfiguration
//
// Durch Ändern der Zeile #define CHANNEL_ANZ (entweder 1 oder 2) stellt sich der 
// gesamte Code vollautomatisch um. Je nachdem, ändert sich die Anzahl der genutzten 
// Pins, die Anzahl der internen Kanäle, die Gerätekennung für die CCU und der 
// Gerätetyp: entweder HM-LC-Sw1-Pl für 1 Kanal oder HM-LC-Sw2-FM für 2 Kanäle
//
// HIER DIE KANALANZAHL DEFINIEREN: Entweder 1 oder 2 eintragen!
//
// CHANNEL_ANZ == 1  =>  Device Model  HM-LC-Sw1-Pl
// CHANNEL_ANZ == 2  =>  Device Model  HM-LC-Sw2-FM

#define CHANNEL_ANZ       2

//---------------------------------------------------------
// Boot-Synchronisation der bistabilen Relais:
//
// 0 = minimale Relaisbetätigung - EEPROM-Inhalt wird als gespeicherter Relais-Zustand übernommen
// 1 = maximale Synchronisationssicherheit - Relais wird beim Booten immer auf den EEPROM-Zustand hin synchronisiert (Standard)
// 2 = Verhalten nahe am Original HM-LC-Sw2-FM - Relais wird nur bei 'kurzen Tastendruck simulieren' geschaltet

#define cRELAY_BOOT_SYNC  1

// Modus 1 wird für bistabile Relais ohne Rückmeldekontakt empfohlen,
// da nach jedem Neustart EEPROM, Relais und CCU garantiert synchron sind
    // AskSin-Zustand setzen, aber Relais immer schalten:
    // CCU-Einstellung                  EEPROM   Relais nach Boot    EEPROM nach Boot
    // Aktion bei Spannungszufuhr
    // keine                            AUS      AUS (RESET-Impuls)  AUS
    // keine                            AN       AN  (SET-Impuls)    AN
    // kurzer Tastendruck simulieren    AUS      AN  (SET-Impuls)    AN
    // kurzer Tastendruck simulieren    AN       AN  (SET-Impuls)    AN
    // Der Vorteil ist, dass jede Desynchronisation automatisch beim nächsten Neustart korrigiert wird. Da es sich 
    // um ein bistabiles Relais handelt, ist ein erneuter SET- oder RESET-Impuls auf den bereits erreichten Zustand 
    // normalerweise unkritisch.

// Modus 2 kann dann als bewusste Option für Anwender dienen, die das Verhalten 
// des originalen HM-LC-Sw2-FM möglichst exakt nachbilden möchten
    // AskSin-Zustand setzen, aber Relais nur bei 'kurzer Tastendruck' schalten:
    // CCU-Einstellung                  EEPROM   Relais nach Boot    EEPROM nach Boot
    // Aktion bei Spannungszufuhr
    // keine                            AUS      AUS                 AUS
    // keine                            AN       AN                  AN
    // kurzer Tastendruck simulieren    AUS      AN  (SET-Impuls)    AN
    // kurzer Tastendruck simulieren    AN       AN  (SET-Impuls)    AN
    // Der Vorteil von Variante 2 ist, dass sie dem Verhalten des originalen HM-LC-Sw2-FM sehr nahe kommt: Die Einstellung
    // 'keine' übernimmt den gespeicherten Zustand unverändert, während 'kurzen Tastendruck simulieren' tatsächlich immer 
    // einen Einschaltimpuls erzeugt – unabhängig davon, was im EEPROM steht.

// Modus 0 minimiert die Relaisimpulse, aber eine Desynchronisation wird dauerhaft beibehalten 
    // AskSin-Zustand setzen, aber Relais nicht schalten:
    // CCU-Einstellung                  EEPROM   Relais nach Boot    EEPROM nach Boot
    // Aktion bei Spannungszufuhr
    // keine                            AUS      AUS                 AUS
    // keine                            AN       AN                  AN
    // kurzer Tastendruck simulieren    AUS      AN  (SET-Impuls)    AN
    // kurzer Tastendruck simulieren    AN       AN                  AN
    // Bei 'keine' wird nie geschaltet, bei 'kurzen Tastendruck simulieren' wird genau dann ein SET-Impuls erzeugt, 
    // wenn das Relais laut EEPROM auf AUS stand. Dadurch bleiben EEPROM, mechanischer Relaiszustand und CCU nach 
    // dem Booten konsistent.

//---------------------------------------------------------
// Device Angaben
//
#if CHANNEL_ANZ == 2
// Device Model  HM-LC-Sw2-FM
// HomeMatic Funk-Schaltaktor 2-fach
// https://github.com/jp112sdl/Beispiel_AskSinPP/blob/master/examples/HM-LC-Sw2-FM/HM-LC-Sw2-FM.ino
#define cDEVICE_MODEL     { 0x00, 0x09 }
#define cDEVICE_ID        { 0x12, 0x09, 0x03 }    // !!! ID's von bereits vorhandener Geräte beachten !!!
#define cDEVICE_SERIAL    "HBL2R00001"            // Test über SSH:  grep -r "120903" /etc/config/rfd
#define cDEVICE_FIRMWARE  0x24
#else
// Device Model  HM-LC-Sw1-Pl
// HomeMatic Funk-Schaltaktor 1-fach
// 
#define cDEVICE_MODEL     { 0x00, 0x11 }
#define cDEVICE_ID        { 0x01, 0x11, 0x01 }    // !!! ID's von bereits vorhandener Geräte beachten !!!
#define cDEVICE_SERIAL    "HBL1R00001"            // Test über SSH:  grep -r "011101" /etc/config/rfd
#define cDEVICE_FIRMWARE  0x24
#endif

//---------------------------------------------------------
// Asksin Parameter
//
// Geräte-LED
// #define cDEVICE_LED_MODE    0    // Geräte-LED = aus
// #define cDEVICE_LED_MODE    1    // Geräte-LED = ein (default)
#define cDEVICE_LED_MODE       1
//
#if cDEVICE_LED_MODE == 0
#define DEVICE_LED_MODE  NoLed
#else
#define DEVICE_LED_MODE  StatusLed<LED_PIN>
#endif
//
// ConfigButton - Modus des Anlern-Buttons
// #define cDEVICE_CB_MODE     0    // Anlern-Modus - kurzer Tastendruck (default)
// #define cDEVICE_CB_MODE     1    // Anlern-Modus - langer Tastendruck
#define cDEVICE_CB_MODE        0

//---------------------------------------------------------
// Asksin Pin-Anschlüsse
// #define CONFIG_BUTTON_PIN      8    // Default Asksin
// #define CONFIG_BUTTON_PIN      9    // Platine HB-L1R-THT oder HB-L2R-THT
#define CONFIG_BUTTON_PIN      9  
#define LED_PIN                4

// Asksin Taster-Anschlüsse - Platine HB-L1R-THT oder HB-L2R-THT
#define BUTTON1_PIN            A1
#if CHANNEL_ANZ == 2
#define BUTTON2_PIN            A2
#endif

//---------------------------------------------------------
// Arduino Pro mini 8 Mhz
// mit CC1101 Sendemodul
#define CC1101_GDO0_PIN        2
#define CC1101_CS_PIN          10
#define CC1101_MOSI_PIN        11
#define CC1101_MISO_PIN        12
#define CC1101_SCK_PIN         13

//---------------------------------------------------------
// Relais Pin-Anschlüsse der N-MOSFET an MCU - Platine HB-L1R-THT oder HB-L2R-THT
//
#define RELAY1_SET_PIN         6    // Impuls zum Einschalten Relais 1 (Q11 - Spule 1 / SET)
#define RELAY1_RESET_PIN       5    // Impuls zum Ausschalten Relais 1 (Q12 - Spule 2 / RESET)

#if CHANNEL_ANZ == 2
#define RELAY2_SET_PIN         8    // Impuls zum Einschalten Relais 2 (Q21 - Spule 1 / SET)
#define RELAY2_RESET_PIN       7    // Impuls zum Ausschalten Relais 2 (Q22 - Spule 2 / RESET)
#endif

//---------------------------------------------------------
// Relais HONGFA HFD2/005-S-L2-D - Dauer Spulen Impuls
//
#define RELAY_PULSE_MS         50   // Relais Impuls [ms]

#endif
