//---------------------------------------------------------
// HB-LxR-THT
//---------------------------------------------------------
// AskSin++ - Aktor für Platine HB-L1R-THT bzw. HB-L2R-THT
//            mit HONGFA HFD2/005-S-L2-D (bistabiles Relais)
// - Kompilierung für 1 oder 2 Kanäle steuerbar via CHANNEL_ANZ
// - HM-LC-Sw1-Pl für 1 Kanal oder HM-LC-Sw2-FM für 2 Kanäle
//
// 2026-08-05 - wolwin Creative Commons
//
// http://creativecommons.org/licenses/by-nc-sa/3.0/de/
// You are free to Share & Adapt under the following terms:
// Give Credit, NonCommercial, ShareAlike
//---------------------------------------------------------

// External Konfiguration
#include "HB-LxR-THT_ext.h"

#define EI_NOTEXTERNAL
#include <EnableInterrupt.h>
#include <AskSinPP.h>
#include <LowPower.h>
#include <Switch.h>

#include <avr/eeprom.h>

// number of available peers per channel
#define PEERS_PER_CHANNEL 8

using namespace as;

const struct DeviceInfo PROGMEM devinfo = {
  cDEVICE_ID,                 // Device ID
  cDEVICE_SERIAL,             // Device Serial
  cDEVICE_MODEL,              // Device Model
  cDEVICE_FIRMWARE,           // Firmware Version
  as::DeviceType::Switch,     // Device Type
  {0x01, 0x00}                // Info Bytes
};

typedef AvrSPI<CC1101_CS_PIN, CC1101_MOSI_PIN, CC1101_MISO_PIN, CC1101_SCK_PIN> RadioSPI;
typedef Radio<RadioSPI, CC1101_GDO0_PIN> RadioType;

// Permanent empfangsbereit am Netzteil (NoBattery)
typedef AskSin<DEVICE_LED_MODE, NoBattery, RadioType> Hal;
Hal hal;

// --- Funktion zum physischen Schalten der Relais-Spulen ---
void pulseRelay(uint8_t setpin, uint8_t resetpin, uint8_t value) {
  // Sicherheitsmaßnahme - beide MOSFET-Ausgänge vor dem Impuls auf AUS setzen
  digitalWrite(setpin, LOW);
  digitalWrite(resetpin, LOW);

  uint8_t activePin = (value != 0) ? setpin : resetpin;

  digitalWrite(activePin, HIGH);
  _delay_ms(RELAY_PULSE_MS);
  digitalWrite(activePin, LOW);

  DPRINT(F("-> pulseRelay ("));  DPRINT(value != 0 ? F("SET-") : F("RESET-"));  DDEC(activePin); DPRINTLN(value != 0 ? F("): AN") : F("): AUS"));

}

// --- Definition für Funktion EEPROM Speicheradresse ---
uint16_t relayStorageAddress(uint8_t channel);

// --- Zustand im EEPROM speichern ---
void saveRelayState (uint8_t channel, uint8_t state) {
  uint16_t address = relayStorageAddress(channel);
  uint8_t value = (state != 0) ? 1 : 0;

  uint8_t oldValue = eeprom_read_byte((uint8_t*)address);

  if (oldValue != value) {
    eeprom_update_byte((uint8_t*)address, value);
    DPRINT(F("-> Schreibe EEPROM Kanal "));  DDEC(channel);  DPRINT(F(" : "));  DPRINTLN(value ? "AN" : "AUS");
  } else {
    DPRINT(F("-> EEPROM Kanal "));  DDEC(channel);  DPRINT(F(" unverändert : "));  DPRINTLN(value ? "AN" : "AUS");
  }
}

// --- Zustand aus EEPROM lesen ---
uint8_t loadRelayState (uint8_t channel) {
  uint16_t address = relayStorageAddress(channel);
  uint8_t eepromValue = eeprom_read_byte((uint8_t*)address);

  uint8_t value = (eepromValue == 1) ? 200 : 0;    // ungültiger/uninitialisierter Wert => AUS;
  DPRINT(F("-> Lese EEPROM Kanal "));  DDEC(channel);  DPRINT(F(" : "));  DDEC(eepromValue);  DPRINT(F(" -> "));  DPRINTLN(value == 0 ? "AUS" : "AN");
  return value;
}

// --- AKTOR-KANAL ---
class MySwitchChannel : public SwitchChannel<Hal, PEERS_PER_CHANNEL, List0> {
  
  typedef SwitchChannel<Hal, PEERS_PER_CHANNEL, List0> BaseChannel;
  
  bool _startupSync;     // Boot-Flag
  uint8_t _lastState;    // letzter EEPROM Relais Status

public:

  MySwitchChannel () : SwitchChannel<Hal, PEERS_PER_CHANNEL, List0>(),
   _startupSync(true),
   _lastState(0)
  {}

  void init(uint8_t p, bool value = false) {
    // SwitchChannel<Hal, PEERS_PER_CHANNEL, List0>::init(p, value);
    // ersetzt durch 
    // Dummy-Pin speichern
    this->pin = p;
    // Nach der Standard-Initialisierung noch im Sync-Modus
    _startupSync = true;
    _lastState   = 0;
  }

  // --- Relais für Kanal schalten ---
  void pulseChannel(uint8_t value) {
      if (this->number() == 1) {
        pulseRelay(RELAY1_SET_PIN, RELAY1_RESET_PIN, value);
      }
#if CHANNEL_ANZ == 2
      else if (this->number() == 2) {
        pulseRelay(RELAY2_SET_PIN, RELAY2_RESET_PIN, value);
      }
#endif
  }

  void restoreState() {

    typename BaseChannel::List1 l1 = this->getList1();

    // im EEPROM gespeicherten Relaiszustand laden
    uint8_t storedState = loadRelayState(this->number());

    // Zielzustand bestimmen
    uint8_t targetState = storedState;

    if (l1.powerUpAction() == true) {
      targetState = 200;     // kurzer Tastendruck simulieren -> AN
    }

    // internen Zustand übernehmen
    _lastState = targetState;

#if cRELAY_BOOT_SYNC == 0

    // -------------------------------------------------------------------------------------------------------------
    // AskSin-Zustand setzen, aber Relais nicht schalten:
    // CCU-Einstellung                  EEPROM   Relais nach Boot    EEPROM nach Boot
    // Aktion bei Spannungszufuhr
    // keine                            AUS      AUS                 AUS
    // keine                            AN       AN                  AN
    // kurzer Tastendruck simulieren    AUS      AN  (SET-Impuls)    AN
    // kurzer Tastendruck simulieren    AN       AN                  AN

    // Bei 'keine' wird nie geschaltet, bei 'kurzen Tastendruck simulieren' wird genau dann ein SET-Impuls erzeugt, 
    // wenn das Relais laut EEPROM auf AUS stand. Dadurch bleiben EEPROM, mechanischer Relaiszustand und CCU nach 
    // dem Booten konsistent.

    // Nur schalten, wenn sich der Zustand ändern muss
    if (storedState != targetState) {

//       if (this->number() == 1) {
//         pulseRelay(RELAY1_SET_PIN, RELAY1_RESET_PIN, targetState);
//       }
// #if CHANNEL_ANZ == 2
//       else if (this->number() == 2) {
//         pulseRelay(RELAY2_SET_PIN, RELAY2_RESET_PIN, targetState);
//       }
// #endif
      // Relais schalten
      pulseChannel(targetState);

      // neuen Relais Zustand in EEPROM speichern
      saveRelayState(this->number(), targetState);
    }
    // -------------------------------------------------------------------------------------------------------------

#elif cRELAY_BOOT_SYNC == 1

    // -------------------------------------------------------------------------------------------------------------
    // AskSin-Zustand setzen, aber Relais immer schalten:
    // CCU-Einstellung                  EEPROM   Relais nach Boot    EEPROM nach Boot
    // Aktion bei Spannungszufuhr
    // keine                            AUS      AUS (RESET-Impuls)  AUS
    // keine                            AN       AN  (SET-Impuls)    AN
    // kurzer Tastendruck simulieren    AUS      AN  (SET-Impuls)    AN
    // kurzer Tastendruck simulieren    AN       AN  (SET-Impuls)    AN

    // Der Vorteil ist, dass jede Desynchronisation automatisch beim nächsten Neustart korrigiert wird. Da es sich 
    // um ein bistabiles Relais handelt, ist ein erneuter SET- oder RESET-Impuls auf den bereits erreichten Zustand 
    // normalerweise unkritisch.

    // Relais beim Booten immer auf den Zielzustand synchronisieren

//     if (this->number() == 1) {
//       pulseRelay(RELAY1_SET_PIN, RELAY1_RESET_PIN, targetState);
//     }
// #if CHANNEL_ANZ == 2
//     else if (this->number() == 2) {
//       pulseRelay(RELAY2_SET_PIN, RELAY2_RESET_PIN, targetState);
//     }
// #endif
    // Relais schalten
    pulseChannel(targetState);

    // neuen Relais Zustand in EEPROM speichern
    saveRelayState(this->number(), targetState);
    // -------------------------------------------------------------------------------------------------------------

#elif cRELAY_BOOT_SYNC == 2

    // -------------------------------------------------------------------------------------------------------------
    // AskSin-Zustand setzen, aber Relais nur bei 'kurzer Tastendruck' schalten:
    // CCU-Einstellung                  EEPROM   Relais nach Boot    EEPROM nach Boot
    // Aktion bei Spannungszufuhr
    // keine                            AUS      AUS                 AUS
    // keine                            AN       AN                  AN
    // kurzer Tastendruck simulieren    AUS      AN  (SET-Impuls)    AN
    // kurzer Tastendruck simulieren    AN       AN  (SET-Impuls)    AN

    // Der Vorteil von Variante 2 ist, dass sie dem Verhalten des originalen HM-LC-Sw2-FM sehr nahe kommt: Die Einstellung
    // 'keine' übernimmt den gespeicherten Zustand unverändert, während 'kurzen Tastendruck simulieren' tatsächlich immer 
    // einen Einschaltimpuls erzeugt – unabhängig davon, was im EEPROM steht.

  if (l1.powerUpAction() == true) {
    // Bei 'kurzen Tastendruck simulieren' immer einen SET-Impuls auslösen

//     if (this->number() == 1) {
//       pulseRelay(RELAY1_SET_PIN, RELAY1_RESET_PIN, 200);
//     }
// #if CHANNEL_ANZ == 2
//     else if (this->number() == 2) {
//       pulseRelay(RELAY2_SET_PIN, RELAY2_RESET_PIN, 200);
//     }
// #endif
    // Relais schalten
    pulseChannel(200);

    // neuen Relais Zustand in EEPROM speichern
    _lastState = 200;
    saveRelayState(this->number(), _lastState);
  } else {
    // Bei 'keine' nie schalten
    _lastState = storedState;
  }

    // -------------------------------------------------------------------------------------------------------------
#endif

    // internen AskSin-Zustand übernehmen
    this->state = (_lastState == 0) ? AS_CM_JT_OFF : AS_CM_JT_ON;

    // Status an die CCU melden
    this->changed(true);

  }

  void startupDone() {
    _startupSync = false;
  }

  uint8_t lastState() const {
    return _lastState;
  }

  virtual void switchState(uint8_t oldstate, uint8_t newstate, uint32_t delay) {

    uint8_t value = (newstate == AS_CM_JT_ON) ? 200 : 0;

    // Nur reagieren, wenn sich der Zustand wirklich geändert hat
    if (value != _lastState) {
      // Nur reagieren, wenn keine Boot-Phase
      if (_startupSync == false) {

//         // Kanal 1
//         if (this->number() == 1) {
//           // Relais physisch schalten
//           pulseRelay(RELAY1_SET_PIN, RELAY1_RESET_PIN, value);
//         }
// #if CHANNEL_ANZ == 2
//         // Kanal 2
//         else if (this->number() == 2) {
//           // Relais physisch schalten
//           pulseRelay(RELAY2_SET_PIN, RELAY2_RESET_PIN, value);
//         }
// #endif
        // Relais schalten
        pulseChannel(value);

        // Relais Status in EEPROM speichern
        saveRelayState(this->number(), value);
      }
      // Relais Status merken
      _lastState = value;
    }

    // this->changed(true);
    SwitchChannel<Hal, PEERS_PER_CHANNEL, List0>::switchState(oldstate, newstate, delay);
    
  }

};

typedef MultiChannelDevice<Hal, MySwitchChannel, CHANNEL_ANZ> SwitchType;
SwitchType sdev(devinfo, 0x20);

// --- Eigene BUTTON Klasse ---
class LocalButton : public Alarm {

  SwitchType& device;
  uint8_t pin;
  uint8_t channel;
  bool lastState;
  bool pending;

public:
  LocalButton(SwitchType& dev, uint8_t p, uint8_t ch)
    : Alarm(0), device(dev), pin(p), channel(ch),
      lastState(HIGH), pending(false) {}

  void init() {
    pinMode(pin, INPUT_PULLUP);
  }

  void check() {
    bool state = digitalRead(pin);

    // Flankenerkennung HIGH -> LOW
    if (lastState == HIGH && state == LOW && pending == false) {
      pending = true;
      set(millis2ticks(30));
      sysclock.add(*this);
    }

    lastState = state;
  }

  virtual void trigger(AlarmClock&) {

    pending = false;

    // Taster nach der Entprellzeit noch gedrückt?
    if (digitalRead(pin) == LOW) {
      device.channel(channel).toggleState();

      DPRINT(F("-> Taster Kanal "));  DDEC(channel);  DPRINTLN(F(" gedrückt"));
    }
  }
};

// --- EEPROM Speicheradresse ---
uint16_t relayStorageAddress(uint8_t channel) {
  return sdev.getUserStorage().getAddress() + (channel - 1);
}

// --- ASKSIN - internal Peerings ---
void initPeerings (bool first) {
  // create internal peerings - CCU2 needs this
  if ( first == true ) {
    HMID devid;
    sdev.getDeviceID(devid);
    for ( uint8_t i = 1; i <= sdev.channels(); ++i ) {
      Peer ipeer(devid, i);
      sdev.channel(i).peer(ipeer);
    }
  }
}

// --- CONFIG-BUTTON ---
#if cDEVICE_CB_MODE == 1
ConfigToggleButton<SwitchType> cfgBtn(sdev);
#else
ConfigButton<SwitchType> cfgBtn(sdev);
#endif

// --- LOCAL-BUTTON ---
LocalButton btn1(sdev, BUTTON1_PIN, 1);
#if CHANNEL_ANZ == 2
LocalButton btn2(sdev, BUTTON2_PIN, 2);
#endif

// --- SETUP ---
void setup () {
  DINIT(57600, ASKSIN_PLUS_PLUS_IDENTIFIER);

  // Physische Pins für Relais als Ausgang konfigurieren
  pinMode(RELAY1_SET_PIN, OUTPUT);
  pinMode(RELAY1_RESET_PIN, OUTPUT);
  digitalWrite(RELAY1_SET_PIN, LOW);
  digitalWrite(RELAY1_RESET_PIN, LOW);

  #if CHANNEL_ANZ == 2
    pinMode(RELAY2_SET_PIN, OUTPUT);
    pinMode(RELAY2_RESET_PIN, OUTPUT);
    digitalWrite(RELAY2_SET_PIN, LOW);
    digitalWrite(RELAY2_RESET_PIN, LOW);
  #endif

  // Aktor-Strukturen und CC1101 initialisieren
  bool first = sdev.init(hal);

  // Initialisierung die AskSin-Kanäle mit fiktiven "Dummy-Pins" (A6=20, A7=21)
  // (damit die Bibliothek glücklich ist - nutzen diese Pins aber physisch gar nicht)
  sdev.channel(1).init(20);
  #if CHANNEL_ANZ == 2
    sdev.channel(2).init(21);
  #endif

  // Anlerntaster aktivieren
  buttonISR(cfgBtn, CONFIG_BUTTON_PIN);

  // Taster aktivieren
  btn1.init();
#if CHANNEL_ANZ == 2
  btn2.init();
#endif

  // Asksin
  initPeerings(first);
  sdev.initDone();

  // Ausgabe Device-ID und Device-SERIAL
  DDEVINFO(sdev);
  DPRINT(F("- Aktor gestartet als ")); DPRINTLN(CHANNEL_ANZ == 2 ? F("HM-LC-Sw2-FM (2-Kanal)") : F("HM-LC-Sw1-Pl (1-Kanal)")); 
  DPRINTLN(F("- Setze Relais Zustand"));

  // Synchronisation EEPROM -> AskSin -> CCU
  sdev.channel(1).restoreState();
#if CHANNEL_ANZ == 2
  sdev.channel(2).restoreState();
#endif

  sdev.channel(1).startupDone();
#if CHANNEL_ANZ == 2
  sdev.channel(2).startupDone();
#endif

  DPRINTLN(F("- Relais Zustand gesetzt"));

}

void loop () {
  // Verarbeitet eingehende Funktelegramme und interne Timer
  bool worked = hal.runready();    // verarbeitet interne Timer und die Status-LED.
  bool poll = sdev.pollRadio();    // prüft, ob das CC1101-Funkmodul Daten empfangen hat

  btn1.check();
#if CHANNEL_ANZ == 2
  btn2.check();
#endif

  if ( worked == false && poll == false ) {
    // Wenn absolut nichts zu tun ist wird der ATmega328P in den CPU-Schnittstellen-Schlafmodus.
    // Der Timer für die LEDs oder ein Funk-Interrupt wecken ihn sofort wieder auf.
    hal.activity.savePower<Idle<> >(hal);
  // } else {
  }
}
