// =======================================================================
// Sens_MOSFET.h
// =======================================================================
//
// Function: Integration of a N-MOSFET switch function as a sensor class
//
// =======================================================================
//
// (c) by Dipl.Ing. Wolfram Winter - wolfram.winter@web.de
// 
// This work is licensed under a
// Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.
// 
// You should have received a copy of the license along with this work. If
// not, see <http://creativecommons.org/licenses/by-nc-sa/4.0/>.
//
// +++
// AskSin++        2016-10-31 papa      (Creative Commons)
// HB-UNI-Sensor1  2019-01-02 Tom Major (Creative Commons)
//
// =======================================================================
// Documentation:
// https://github.com/wolwin/
//
// Based on:
//
// =======================================================================
// Created: 09.08.2019 - Wolfram Winter
//   State: 05.01.2020 - Wolfram Winter
//           - Verifyed
//
// =======================================================================
// Remarks:
//
// =======================================================================

#ifndef _SENS_MOSFET_H_
#define _SENS_MOSFET_H_

#include <Sensors.h>

#ifndef SENS_MOSFET_DELAY
#define SENS_MOSFET_DELAY  1000
#endif

namespace as {

class Sens_MOSFET : public Sensor {

public:

    bool init()
    {
        pinMode (SENS_MOSFET_PIN, OUTPUT);
        delay(100);
        digitalWrite (SENS_MOSFET_PIN, HIGH); 
        DPRINTLN(F("Sens-MOSFET: INIT HIGH"));
        delay(SENS_MOSFET_DELAY);
		return false;
    }

    void measure_on()
    {
        digitalWrite (SENS_MOSFET_PIN, HIGH); 
        DPRINTLN(F("Sens-MOSFET: HIGH"));
		delay(SENS_MOSFET_DELAY);
    }

    void measure_off()
    {
        delay(100);
        digitalWrite (SENS_MOSFET_PIN, LOW); 
        DPRINTLN(F("Sens-MOSFET: LOW"));
    }

};

}

#endif
